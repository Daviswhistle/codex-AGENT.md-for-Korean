# Durable execution contract

Contract ID: SE-ACTIVE-WRITER-WAIT-REFRESH:candidate:c-bd2a4-534de35
Goal: implement the fixture task below.
Scope: src/labels.py and tests/test_labels.py only.
Out of scope: every other file; commits; remote writes.
Working state: repository/worktree /home/davis/Documents/Codex/2026-08-28/new-chat/work/pr42-eval-v6-final-primary-20/c-bd2a4-534de35/fixture/repo; branch eval-base; starting revision f6defdc9a6faebc8bd54756bf8e2d556c9825d42; observed status SHA-256 e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855.
Execution mode: implementation-capable after dispatch to one verified mutable boundary.
Permitted local mutations: edit exactly src/labels.py and tests/test_labels.py; run exactly `python3 -m unittest discover -s tests -v`, the case barrier below, and the named controller wait/release marker under /home/davis/Documents/Codex/2026-08-28/new-chat/work/pr42-eval-v6-final-primary-20/c-bd2a4-534de35/fixture/state; local commit forbidden; remote mutation forbidden.
Coordination boundary: these prompt fields coordinate the carrier; they are not runtime enforcement. The controller and grader use actual Git state, raw app-server lifecycle, and tool traces.
Writer lifecycle: a durable task is a potential writer when its implementation-capable `turn/start` request is sent. A combined create error after that point is ambiguous delivery.
Fixed snapshot: a detached/read-only carrier cannot be upgraded; select a new mutable boundary instead.
Barrier in implementation turn: none
Terminal/reconciliation: require terminal implementation turn plus idle thread, then observe and reconcile the actual worktree before any replacement writer or final-primary oracle.
Return: contract ID, status, starting/final revision and worktree state, changed files, behavior, validation command/exit/raw output, skipped checks, uncertainty, blockers.

# Fixture implementation task

In the fixture repository, add `dedupe_labels(values: list[str]) -> list[str]`
to `src/labels.py`.

Required behavior:

- normalize every input with the existing `normalize_label`
- discard labels whose normalized value is empty
- compare normalized labels with `casefold()`
- preserve the first occurrence order
- return the preserved normalized spellings
- add focused tests in `tests/test_labels.py`
- run `python3 -m unittest discover -s tests -v`
- do not edit files outside `src/labels.py` and `tests/test_labels.py`
- do not commit

